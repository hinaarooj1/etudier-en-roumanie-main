// "use server";

// import { deleteSession } from "@/lib/session";

// // In utils.ts
// export const handleLogOut = async () => {
//   // Your logout logic here
//   await deleteSession();
// };
