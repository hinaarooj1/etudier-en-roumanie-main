import CalendlyWidget from "@/components/CalendlyWidget";

const SchedulePage = () => {
  return (
    <div style={{ padding: "20px" }} >
      <CalendlyWidget />
    </div>
  );
};

export default SchedulePage;
