(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_(client)_page_jsx_d1dc87._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_(client)_page_jsx_d1dc87._.js",
  "chunks": [
    "static/chunks/node_modules_a5d188._.js",
    "static/chunks/_fe1b2b._.js"
  ],
  "source": "dynamic"
});
