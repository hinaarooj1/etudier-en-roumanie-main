(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_admin_layout_jsx_bd35ea._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_admin_layout_jsx_bd35ea._.js",
  "chunks": [
    "static/chunks/app_[lang]_admin_layout_jsx_f5bd5d._.js"
  ],
  "source": "dynamic"
});
