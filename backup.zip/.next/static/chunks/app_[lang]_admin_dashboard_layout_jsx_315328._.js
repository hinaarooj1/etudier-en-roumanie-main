(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_admin_dashboard_layout_jsx_315328._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_admin_dashboard_layout_jsx_315328._.js",
  "chunks": [
    "static/chunks/_77b4c8._.js",
    "static/chunks/node_modules_de4088._.js"
  ],
  "source": "dynamic"
});
