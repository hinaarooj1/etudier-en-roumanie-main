(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_(client)_contact_page_jsx_ca57b8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_(client)_contact_page_jsx_ca57b8._.js",
  "chunks": [
    "static/chunks/node_modules_1fa29c._.js",
    "static/chunks/_943dd7._.js"
  ],
  "source": "dynamic"
});
