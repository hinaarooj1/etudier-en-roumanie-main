(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_(client)_layout_jsx_bd35ea._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_(client)_layout_jsx_bd35ea._.js",
  "chunks": [
    "static/chunks/node_modules_next_b0b1bd._.js",
    "static/chunks/node_modules_framer-motion_dist_es_81d720._.js",
    "static/chunks/a480a_tailwind-merge_dist_lib_983356._.js",
    "static/chunks/node_modules_@react-aria_ba53c9._.js",
    "static/chunks/node_modules_@nextui-org_shared-utils_dist_2a3169._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_io_index_mjs_d35cf4._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_018979._.js",
    "static/chunks/_d67aa1._.js",
    "static/chunks/[next]_internal_font_google_3f6cd0._.css",
    "static/chunks/node_modules_@nextui-org_dom-animation_dist_index_mjs_14a1e6._.js"
  ],
  "source": "dynamic"
});
