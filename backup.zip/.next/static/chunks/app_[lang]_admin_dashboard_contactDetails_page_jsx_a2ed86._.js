(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_admin_dashboard_contactDetails_page_jsx_a2ed86._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_admin_dashboard_contactDetails_page_jsx_a2ed86._.js",
  "chunks": [
    "static/chunks/node_modules_fa6e3d._.js",
    "static/chunks/_1863c0._.js"
  ],
  "source": "dynamic"
});
