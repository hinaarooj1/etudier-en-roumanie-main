(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_layout_jsx_104112._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_layout_jsx_104112._.js",
  "chunks": [
    "static/chunks/styles_globals_824228.css",
    "static/chunks/_6a46aa._.js"
  ],
  "source": "dynamic"
});
