(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_admin_dashboard_page_jsx_a2ed86._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_admin_dashboard_page_jsx_a2ed86._.js",
  "chunks": [
    "static/chunks/node_modules_3f0884._.js",
    "static/chunks/_b3c56a._.js"
  ],
  "source": "dynamic"
});
