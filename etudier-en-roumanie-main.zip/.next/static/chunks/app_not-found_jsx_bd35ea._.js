(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_not-found_jsx_bd35ea._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_not-found_jsx_bd35ea._.js",
  "chunks": [
    "static/chunks/_78592a._.js"
  ],
  "source": "dynamic"
});
