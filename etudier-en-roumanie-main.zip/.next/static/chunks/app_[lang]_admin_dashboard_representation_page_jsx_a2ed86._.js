(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_admin_dashboard_representation_page_jsx_a2ed86._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_admin_dashboard_representation_page_jsx_a2ed86._.js",
  "chunks": [
    "static/chunks/node_modules_190087._.js",
    "static/chunks/_bbc7e1._.js"
  ],
  "source": "dynamic"
});
