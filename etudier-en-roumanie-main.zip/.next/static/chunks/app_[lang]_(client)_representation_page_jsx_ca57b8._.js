(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_(client)_representation_page_jsx_ca57b8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_(client)_representation_page_jsx_ca57b8._.js",
  "chunks": [
    "static/chunks/app_[lang]_(client)_representation_page_jsx_125751._.js"
  ],
  "source": "dynamic"
});
