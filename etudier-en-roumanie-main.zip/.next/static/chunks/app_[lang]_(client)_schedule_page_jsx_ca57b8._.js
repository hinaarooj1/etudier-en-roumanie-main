(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_(client)_schedule_page_jsx_ca57b8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_(client)_schedule_page_jsx_ca57b8._.js",
  "chunks": [
    "static/chunks/_88532a._.js"
  ],
  "source": "dynamic"
});
