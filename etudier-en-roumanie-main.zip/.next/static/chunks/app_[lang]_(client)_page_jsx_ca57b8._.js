(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_(client)_page_jsx_ca57b8._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_(client)_page_jsx_ca57b8._.js",
  "chunks": [
    "static/chunks/_e5fc1a._.js",
    "static/chunks/node_modules_deade7._.js"
  ],
  "source": "dynamic"
});
