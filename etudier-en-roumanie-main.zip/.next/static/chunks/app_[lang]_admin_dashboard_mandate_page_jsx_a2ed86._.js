(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_[lang]_admin_dashboard_mandate_page_jsx_a2ed86._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_[lang]_admin_dashboard_mandate_page_jsx_a2ed86._.js",
  "chunks": [
    "static/chunks/_ee2787._.js",
    "static/chunks/node_modules_a49f6b._.js",
    "static/chunks/_806d30._.js"
  ],
  "source": "dynamic"
});
