export const i18n = {
  defaultLocale: "en",
  locales: ["en", "de", "cs"],
};
