import "../../../styles/globals.css";
export default function RootLayout({ children }) {
  return (
        <main>{children}</main>
    // <html suppressHydrationWarning lang="en">
    //   <head />

    //   <body>
    //   </body>
    // </html>
  );
}
